var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["4711e161-1ce1-4b90-8438-652318fcf677","62a592fd-5a78-4220-90fb-0b2e13374d6d","d66c586c-9206-4517-a324-c3c182eeb862","b5f0f738-e132-484e-87d4-01338b09c1c8"],"propsByKey":{"4711e161-1ce1-4b90-8438-652318fcf677":{"name":"blue_ball","sourceUrl":"assets/api/v1/animation-library/ZcIQw0JGBUToZOAPp7oINBkoy002x4UH/category_characters/alienBlue_badge.png","frameSize":{"x":49,"y":49},"frameCount":2,"looping":true,"frameDelay":10,"version":"ZcIQw0JGBUToZOAPp7oINBkoy002x4UH","loadedFromSource":true,"saved":true,"sourceSize":{"x":98,"y":49},"rootRelativePath":"assets/api/v1/animation-library/ZcIQw0JGBUToZOAPp7oINBkoy002x4UH/category_characters/alienBlue_badge.png"},"62a592fd-5a78-4220-90fb-0b2e13374d6d":{"name":"green_ball","sourceUrl":"assets/api/v1/animation-library/qS.WwmxGU.eNgUN0CjuAI1vIsxalTi9x/category_characters/alienGreen_badge.png","frameSize":{"x":49,"y":49},"frameCount":2,"looping":true,"frameDelay":5,"version":"qS.WwmxGU.eNgUN0CjuAI1vIsxalTi9x","loadedFromSource":true,"saved":true,"sourceSize":{"x":98,"y":49},"rootRelativePath":"assets/api/v1/animation-library/qS.WwmxGU.eNgUN0CjuAI1vIsxalTi9x/category_characters/alienGreen_badge.png"},"d66c586c-9206-4517-a324-c3c182eeb862":{"name":"silver_ball","sourceUrl":"assets/api/v1/animation-library/vOdajK6KZGj20TqNy7gJo9YfriC9FDfl/category_gameplay/coin_silver.png","frameSize":{"x":61,"y":61},"frameCount":1,"looping":true,"frameDelay":2,"version":"vOdajK6KZGj20TqNy7gJo9YfriC9FDfl","loadedFromSource":true,"saved":true,"sourceSize":{"x":61,"y":61},"rootRelativePath":"assets/api/v1/animation-library/vOdajK6KZGj20TqNy7gJo9YfriC9FDfl/category_gameplay/coin_silver.png"},"b5f0f738-e132-484e-87d4-01338b09c1c8":{"name":"bronze_ball","sourceUrl":"assets/api/v1/animation-library/uqjnPX34Zq4tu_YRF_P_sAQ28huvzwwX/category_gameplay/bronze.png","frameSize":{"x":86,"y":86},"frameCount":6,"looping":true,"frameDelay":4,"version":"uqjnPX34Zq4tu_YRF_P_sAQ28huvzwwX","loadedFromSource":true,"saved":true,"sourceSize":{"x":516,"y":86},"rootRelativePath":"assets/api/v1/animation-library/uqjnPX34Zq4tu_YRF_P_sAQ28huvzwwX/category_gameplay/bronze.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----


/*

In this project we are going to recreate gravity using 4 balls/sprites.
Create 4 sprites. You can give it any animation for setAnimation 
(Ball, person jumping...).

Each sprite should a different gravity
Every time the sprite COLLIDES with the ground bounce the sprite back in the air.

Observe how high the sprite bounces off the ground and how long it takes
to get to the ground.

Understand the impact each variable has on the sprite.

OPTIONAL:
You can have different velocities for each sprite as well.
Every time the sprite collides with the ground, give that sprite +1 point.

*/



// Create a global startVelocity variable



// Create the first sprite and setAnimation to the sprite
// Also set it's gravity
var ball1 = createSprite(50, 350);
ball1.setAnimation("blue_ball");


// Create the second sprite and setAnimation to the sprite
// Also set it's gravity
var ball2 = createSprite(150, 350);
ball2.setAnimation("green_ball");
// Create the third sprite and setAnimation to the sprite
// Also set it's gravity

var ball3 = createSprite(250, 350);
ball3.setAnimation("silver_ball");
// Create the fourth sprite and setAnimation to the sprite
// Also set it's gravity
var ball4 = createSprite(350, 350);
ball4.setAnimation("bronze_ball");

var score1 = 0;
var score2 = 0;
var score3 = 0;
var score4 = 0;
function draw() {
  background("pink");
  
  textSize(18);
  text(score4, 350, 20);
  text(score3, 250, 20);
  text(score2, 150, 20);
  text(score1, 50, 20);
  createEdgeSprites();
  
  
  /* 
    Create the condition where we find out if the first sprite collides
    with the bottomEdge :
      IF SO - give it the intended velocity.
  */
  if (ball1.collide(bottomEdge)) {
    ball1.velocityY = -10;
    score1 = score1+1;
  }
  
  if (ball2.collide(bottomEdge)) {
    ball2.velocityY = -18;
    score2 = score2+1;
  }
  
  if (ball3.collide(bottomEdge)) {
    ball3.velocityY = -11;
    score3 = score3+1;
  }
  
  if (ball4.collide(bottomEdge)) {
    ball4.velocityY = -15;
    score4 = score4+1;
  }
  
  
  /* 
    Now when the sprite doesn't collide with the ground,
    Add gravity to the ball.
    You have learnt how to do it in the Trex Class.
  */
 
  ball1.velocityY=ball1.velocityY+0.8;
  ball2.velocityY=ball2.velocityY+0.8;
  ball3.velocityY=ball3.velocityY+0.8;
  ball4.velocityY=ball4.velocityY+0.8;
  drawSprites();
  }
  // DO THE SAME FOR THE REST OF THE SPRITES

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
